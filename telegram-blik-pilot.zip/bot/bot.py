print('Telegram bot placeholder')
